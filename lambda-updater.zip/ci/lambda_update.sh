#!/bin/bash

pip install -U -r requirements.txt -t ./dist
cp resume_submission/*.py dist/
cd dist/
zip lambda-updater.zip -r ./

# aws lambda update-function-code --function-name my-test-website --zip-file fileb://my-deployment-package --profile my-aws-account
