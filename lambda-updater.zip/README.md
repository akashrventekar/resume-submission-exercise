# resume-submission-exercise
This repo contains code that will be used for resume submission exercise

## Features
This code is deployed on AWS Lambda which provides answers to specific questions

## Tests
Tests are written in pytest and are in the tests folder

## Design

I have used API Gateway backed by Lambda (Integration request: Lambda proxy as that is easier for plain text replies)

My initial thought process for the puzzle:
Few ways that would help solve problem:
Fill in the blanks approach
Use BST


Time Complexity: TBD
Space Complexity: TBD
